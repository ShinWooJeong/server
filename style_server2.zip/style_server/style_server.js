var express = require('express');
var fs = require('fs');
const cors = require('cors');
var bodyParser = require('body-parser');

var app = express();
//var port = 3300;
app.use(cors());
app.use(express.static('public')); //경로는 http://localhost:3300/style/style.json

//express 미들웨어 bodyparser을 이용해 POST로 들어온 body에 있는 request를 알아내자
app.use(bodyParser.urlencoded({ extended: false}))
app.use(bodyParser.json())



///////////////////////// 데이터베이스 연결 //////////////////////////
const { Client } = require('pg');
var connectionString = "postgres://postgres:chzhzh1212@localhost:5433/location";

const client = new Client({
    connectionString: connectionString
});

client.connect();
/////////////////////////////////////////////////////////////////////

// 익스프레스 앱 포트 설정
app.set('port', process.env.PORT || 3300);
// 라우터 객체 참조 - 마지막에 라우터 객체 꼭 참조 해줘야함
var router = express.Router();


router.route('/readdir').get(function (req, res) {  // get 으로 테이블 조회
  fs.readdir('./public/style/wemap/', (err, _stylelist) => {
    if (err) {
      console.log(err);
      res.status(500).send('Internal Server Error');
    }

    res.send({ stylelist: _stylelist });
  });
});

router.route('/location').get(function (req, res) {
  client.query('SELECT * FROM location_table', function (err, result) {
      if (err) {
          console.log('database query error occures.. :(( : ', err);
          res.status(400).send(err);
      }
      res.status(200).send(result.rows);
  });
});


router.route('/location').post(function (req, res) { // post 로 테이블에 값 추가
  var location = req.body.location;
  var longitude = req.body.longitude;
  var latitude = req.body.latitude;
  var zoom = req.body.zoom;
  var pitch = req.body.pitch;
  var bearing = req.body.bearing;

  client.query('INSERT INTO location_table (longitude, latitude, location, zoom, pitch, bearing) VALUES ($1, $2, $3, $4, $5, $6)', [longitude,latitude,location,zoom,pitch,bearing], function (err, result) {
    if (err) {
      console.log("query insert has something wrong :(  ", err)
      res.status(400).send(err);
    }
    else {
      console.log('row inserted : ', + longitude + ', ' + latitude + ', ' + location );
      res.redirect('http://192.168.0.4:3300/location');
    }
  })
})
// 라우터 객체 등록 //
app.use('/', router);

////////////////////////////////////////////////////////////////
app.listen(app.get('port'), function () {
  console.log('Server is running.. on Port 3300! :) ');
});